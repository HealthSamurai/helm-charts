# payerbox

Umbrella Helm chart for the **Smartbox payor + ePA stack**. One release deploys the whole stack
into a single namespace:

- **FHIR App Portal** — admin + developer portals (`fhir-app-portal`)
- **Interop APIs** — Patient / Provider / Payer-to-Payer / Provider Directory (`interop`)
- **Prior Auth** — CRD / DTR / PAS (`prior-auth`)
- **Two Aidbox FHIR servers** — `aidbox-admin` (production data) and `aidbox-sandbox` (developer/test data)

![Version: 0.1.7](https://img.shields.io/badge/Version-0.1.7-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 2605](https://img.shields.io/badge/AppVersion-2605-informational?style=flat-square)

The chart bundles the [`aidbox`](https://healthsamurai.github.io/helm-charts) chart (used twice,
unchanged) plus the three Smartbox app charts. Installing the published chart is self-contained —
all subcharts are vendored into the package.

## Installation — step by step

The chart deploys **only the applications and the two Aidbox instances**. It does **not** create
PostgreSQL or any Secret — you provision those first. Do the steps in order: **if you skip
step 2, the pods will not start.**

| Step | What you do | Details |
|---|---|---|
| **1** | Install the cluster add-ons: External Secrets Operator, CloudNativePG, an ingress controller (and/or Gateway API), cert-manager + a `ClusterIssuer` | [PREREQUISITES §1](./PREREQUISITES.md#1-operators--controllers) |
| **2** | **Create 6 Secrets containing 23 keys — every key is required** | [below](#step-2--create-the-secrets) + [PREREQUISITES §2](./PREREQUISITES.md#2-secrets) |
| **3** | Create PostgreSQL with two databases, `portal` and `sandbox` | [PREREQUISITES §3](./PREREQUISITES.md#3-postgresql-cloudnativepg) |
| **4** | Write your `values.yaml` (hostnames and public URLs) | [below](#step-4--write-valuesyaml) |
| **5** | `helm upgrade --install` | [below](#step-5--install) |
| **6** | Check that every pod is `Running` | [below](#step-6--verify) |

You also need **two Aidbox licenses** (admin + sandbox) from Health Samurai — they go into the
Secrets in step 2.

### Step 1 — Install the cluster add-ons

See [PREREQUISITES §1](./PREREQUISITES.md#1-operators--controllers).

### Step 2 — Create the Secrets

> **The chart does not create any Secret.** Each Secret below must exist in the release
> namespace **with all of its keys** before you install. The left column is the Secret's name;
> the right column lists the keys that must be **inside** it — you set all of them, not just the
> Secret name.

| Secret (in namespace `payerbox`) | Keys it must contain — **all required** |
|---|---|
| `payerbox-db-credentials` (type `kubernetes.io/basic-auth`) | `username`, `password` |
| `aidbox-admin-env` | `BOX_LICENSE`, `BOX_ADMIN_PASSWORD`, `BOX_ROOT_CLIENT_SECRET`, `BOX_DB_USER`, `BOX_DB_PASSWORD`, `ADMIN_API_CLIENT_SECRET`, `INTEROP_APP_CLIENT_SECRET`, `PRIOR_AUTH_APP_CLIENT_SECRET` |
| `aidbox-sandbox-env` | `BOX_LICENSE`, `BOX_ADMIN_PASSWORD`, `BOX_ROOT_CLIENT_SECRET`, `BOX_DB_USER`, `BOX_DB_PASSWORD`, `DEVELOPER_API_CLIENT_SECRET` |
| `fhir-app-portal-secrets` | `SESSION_SECRET`, `ADMIN_API_CLIENT_SECRET`, `DEVELOPER_API_CLIENT_SECRET` |
| `interop-secrets` | `AIDBOX_CLIENT_SECRET`, `AIDBOX_APP_SECRET` |
| `prior-auth-secrets` | `AIDBOX_CLIENT_SECRET`, `AIDBOX_APP_SECRET` |

Several values are shared between Secrets and **must be identical** (e.g. the DB password, or
`ADMIN_API_CLIENT_SECRET` in both `aidbox-admin-env` and `fhir-app-portal-secrets`).
[PREREQUISITES §2](./PREREQUISITES.md#2-secrets) explains what goes into each key and has
copy-paste setups for **GCP Secret Manager**, **Azure Key Vault** (both via External Secrets
Operator) and plain `kubectl` for test environments.

**Check before you continue.** This prints `MISSING` for any Secret or key that isn't there:

```bash
NS=payerbox
check() {
  secret=$1; shift
  for key in "$@"; do
    if [ -n "$(kubectl -n "$NS" get secret "$secret" -o "jsonpath={.data.$key}" 2>/dev/null)" ]; then
      echo "ok       $secret/$key"
    else
      echo "MISSING  $secret/$key"
    fi
  done
}
check payerbox-db-credentials username password
check aidbox-admin-env BOX_LICENSE BOX_ADMIN_PASSWORD BOX_ROOT_CLIENT_SECRET BOX_DB_USER BOX_DB_PASSWORD \
  ADMIN_API_CLIENT_SECRET INTEROP_APP_CLIENT_SECRET PRIOR_AUTH_APP_CLIENT_SECRET
check aidbox-sandbox-env BOX_LICENSE BOX_ADMIN_PASSWORD BOX_ROOT_CLIENT_SECRET BOX_DB_USER BOX_DB_PASSWORD \
  DEVELOPER_API_CLIENT_SECRET
check fhir-app-portal-secrets SESSION_SECRET ADMIN_API_CLIENT_SECRET DEVELOPER_API_CLIENT_SECRET
check interop-secrets AIDBOX_CLIENT_SECRET AIDBOX_APP_SECRET
check prior-auth-secrets AIDBOX_CLIENT_SECRET AIDBOX_APP_SECRET
```

All 23 lines must say `ok`.

### Step 3 — Create PostgreSQL

Two databases, `portal` (admin Aidbox) and `sandbox` (sandbox Aidbox), owned by the role from
`payerbox-db-credentials`. The chart expects the host `payerbox-db-rw` (a CloudNativePG `Cluster`
named `payerbox-db`); any reachable Postgres works if you override `aidbox-*.config.BOX_DB_HOST`.
Example `Cluster`: [PREREQUISITES §3](./PREREQUISITES.md#3-postgresql-cloudnativepg).

### Step 4 — Write `values.yaml`

A minimal `values.yaml` overriding the per-environment hosts and URLs:

```yaml
# --- Aidbox: public hosts (drive BOX_WEB_BASE_URL and the OAuth token issuer) ---
aidbox-admin:
  host: aidbox.example.com
  config:
    ADMIN_FRONTEND_URL: https://portal.example.com          # substituted into the admin init-bundle
aidbox-sandbox:
  host: aidbox-sandbox.example.com
  config:
    DEVELOPER_FRONTEND_URL: https://portal-sandbox.example.com   # substituted into the sandbox init-bundle
    ADMIN_AIDBOX_PUBLIC_URL: https://aidbox.example.com          # admin token issuer (introspector iss)
    # AIDBOX_ADMIN_URL defaults to http://aidbox-admin-api (in-cluster JWKS) — usually no override

# --- Portal: hostnames + the URLs it advertises to the browser ---
fhir-app-portal:
  portalHost: portal.example.com
  sandboxHost: portal-sandbox.example.com
  config:
    CORS_ORIGINS: "https://portal.example.com,https://portal-sandbox.example.com"
    ADMIN_FRONTEND_URL: "https://portal.example.com"
    DEVELOPER_FRONTEND_URL: "https://portal-sandbox.example.com"
    AIDBOX_ADMIN_PUBLIC_URL: "https://aidbox.example.com"
    ADMIN_AIDBOX_PUBLIC_URL: "https://aidbox.example.com"
    AIDBOX_DEV_PUBLIC_URL: "https://aidbox-sandbox.example.com"
    DEVELOPER_AIDBOX_PUBLIC_URL: "https://aidbox-sandbox.example.com"
```

For ingress vs. Gateway API, see [Routing & TLS](#routing--tls); for all keys, see [Values](#values).

### Step 5 — Install

```console
helm repo add healthsamurai https://healthsamurai.github.io/helm-charts

helm upgrade --install payerbox healthsamurai/payerbox \
  --namespace payerbox \
  --values /path/to/values.yaml
```

Use the same namespace as the Secrets from step 2 (add `--create-namespace` only if it doesn't
exist yet).

### Step 6 — Verify

```bash
kubectl -n payerbox get pods
```

All pods should reach `Running`. The first Aidbox boot loads the FHIR packages and can take
several minutes. Common failures:

| Symptom | Likely cause |
|---|---|
| `CreateContainerConfigError` | a Secret or a key from step 2 is missing — rerun the check; `kubectl -n payerbox describe pod <pod>` names it |
| Aidbox `CrashLoopBackOff` | invalid/missing `BOX_LICENSE`, or the DB is unreachable / `BOX_DB_PASSWORD` doesn't match the Postgres role |
| Portal login fails with 401 | `ADMIN_API_CLIENT_SECRET` / `DEVELOPER_API_CLIENT_SECRET` differ between the Aidbox and portal Secrets |
| interop / prior-auth keep restarting | `AIDBOX_CLIENT_SECRET` / `AIDBOX_APP_SECRET` missing, or the admin Aidbox isn't up yet |

> A complete, end-to-end walkthrough (PostgreSQL, Secrets, DNS/TLS, verification) is in the
> Payerbox documentation under **Run Payerbox → Deploy**.

## Routing & TLS

Each component chooses **nginx Ingress** or **Gateway API** independently:

- **FHIR App Portal** defaults to **Gateway API** (`route.portal` / `route.dev-portal` → `HTTPRoute`s).
  To use a classic `Ingress` instead, disable the routes and enable ingress:
  ```yaml
  fhir-app-portal:
    route: { portal: { enabled: false }, dev-portal: { enabled: false } }
    ingress: { enabled: true, className: nginx }
    tlsSecretName: fhir-portal-tls
  ```
- **Aidbox admin/sandbox** use **Ingress only** (the `aidbox` chart has no Gateway support);
  enabled by default with `cert-manager.io/cluster-issuer: letsencrypt`.
- **interop / prior-auth** are **ClusterIP-internal** by default (no external route needed).

## Aidbox init bundles & environment substitution

Each Aidbox instance loads a starter **init bundle** (`files/aidbox-*-init-bundle.json`) that
registers the OAuth clients, the cross-instance `TokenIntrospector`, search parameters, and
access policies. Aidbox loads init bundles **as-is** (no native env substitution), so the chart
ships them as `${VAR}` templates and renders them with a small **`sed` initContainer** (`busybox`)
on each Aidbox pod:

- **Non-secret values** (hostnames, the in-cluster admin URL) come from `aidbox-*.config`
  (i.e. your `values.yaml`).
- **Secret values** (client secrets) come from the `aidbox-*-env` Secret via `secretKeyRef` —
  they are never written into a ConfigMap.
- `sed` replaces only the exact `${VAR}` placeholders, so Aidbox matcho operators (`$one-of`,
  `$sql`, …) inside the bundle are left untouched.

Because rendering happens at every pod start, config changes take effect on the next rollout and
**survive `helm upgrade`** — no manual patching.

## Values

| Key | Description | Default |
|---|---|---|
| `aidbox-admin.host` / `aidbox-sandbox.host` | Public hostname of each Aidbox (drives `BOX_WEB_BASE_URL` and the OAuth token `iss`) | `aidbox.example.com` / `aidbox-sandbox.example.com` |
| `aidbox-*.config.BOX_DB_HOST` | PostgreSQL host | `payerbox-db-rw` (CNPG `-rw` Service of `Cluster/payerbox-db`) |
| `aidbox-*.config.BOX_DB_DATABASE` | Database name | `portal` / `sandbox` |
| `aidbox-*.extraEnvFromSecrets` | Secret(s) with `BOX_LICENSE`, DB creds, client secrets | `[aidbox-admin-env]` / `[aidbox-sandbox-env]` |
| `aidbox-admin.config.BOX_BOOTSTRAP_FHIR_PACKAGES` | FHIR packages loaded on the **first** boot against an empty database — R4 core, HL7 Terminology, US Core, CARIN BB and the Da Vinci IGs (HRex / CRD / DTR / PAS / CDex / PDex / Plan-Net / Drug Formulary). Replaced wholesale when overridden | see `values.yaml` |
| `aidbox-admin.config.BOX_FHIR_VALIDATION_SKIP_REFERENCE` | Skip reference resolution during validation — required by the interop `$bulk-member-match`, whose match inputs reference resources that are not stored in the box | `true` |
| `aidbox-admin.config.ADMIN_FRONTEND_URL` | Admin portal URL, substituted into the admin init-bundle | `https://portal.example.com` |
| `aidbox-sandbox.config.DEVELOPER_FRONTEND_URL` | Developer portal URL, substituted into the sandbox init-bundle | `https://portal-sandbox.example.com` |
| `aidbox-sandbox.config.ADMIN_AIDBOX_PUBLIC_URL` | Admin Aidbox token issuer (introspector `iss`) | `https://aidbox.example.com` |
| `aidbox-sandbox.config.AIDBOX_ADMIN_URL` | In-cluster admin Aidbox (JWKS fetch) | `http://aidbox-admin-api` |
| `fhir-app-portal.portalHost` / `.sandboxHost` | Admin / developer portal hostnames | `portal.example.com` / `portal-sandbox.example.com` |
| `fhir-app-portal.config.*` | Portal runtime URLs (CORS, frontend, Aidbox public) | `*.example.com` placeholders |
| `<component>.enabled` | Toggle each subchart | `true` |
| `<component>.resources` | CPU/memory requests & limits | see `values.yaml` |

See [`values.yaml`](./values.yaml) for the full set, and each app chart's `PREREQUISITES.md`
(`fhir-app-portal`, `interop`, `prior-auth`) for its Secret keys and routing options.
